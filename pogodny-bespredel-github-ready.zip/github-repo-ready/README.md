# Погодный беспредел: Android

Нативный Android-проект на Kotlin и Jetpack Compose.

## Сборка APK

GitHub Actions запускает сборку автоматически при push в main/master. Также можно запустить вручную: Actions → Build Android APK → Run workflow.

Готовый APK: Actions → успешный запуск → Artifacts → pogodny-bespredel-debug-apk.

Локально: `./gradlew assembleDebug`. APK появится в `app/build/outputs/apk/debug/app-debug.apk`.
