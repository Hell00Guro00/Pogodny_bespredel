package ru.pogodnybespredel

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.URL

data class WeatherNow(
    val temperature: Double,
    val feelsLike: Double,
    val humidity: Int,
    val wind: Double,
    val pressure: Double,
    val code: Int,
    val description: String,
    val icon: String,
    val comment: String
)

object WeatherRepository {
    suspend fun current(latitude: Double, longitude: Double): WeatherNow = withContext(Dispatchers.IO) {
        val url = URL("https://api.open-meteo.com/v1/forecast?latitude=$latitude&longitude=$longitude&current=temperature_2m,relative_humidity_2m,apparent_temperature,weather_code,wind_speed_10m,surface_pressure&timezone=auto")
        val json = JSONObject(url.readText())
        val c = json.getJSONObject("current")
        val code = c.getInt("weather_code")
        val temp = c.getDouble("temperature_2m")
        val wind = c.getDouble("wind_speed_10m")
        val (icon, desc) = describe(code)
        WeatherNow(
            temp, c.getDouble("apparent_temperature"), c.getInt("relative_humidity_2m"),
            wind, c.getDouble("surface_pressure"), code, desc, icon,
            verdict(temp, code, wind)
        )
    }

    private fun describe(code: Int): Pair<String, String> = when (code) {
        0 -> "☀️" to "Ясно"
        1, 2 -> "🌤️" to "Переменная облачность"
        3 -> "☁️" to "Облачно"
        45, 48 -> "🌫️" to "Туман"
        in 51..67 -> "🌧️" to "Дождь или морось"
        in 71..77 -> "❄️" to "Снег"
        in 80..82 -> "🌦️" to "Ливень"
        85, 86 -> "🌨️" to "Снегопад"
        else -> "⛈️" to "Гроза или непогода"
    }

    private fun verdict(temp: Double, code: Int, wind: Double): String = when {
        code >= 95 -> "Небо устроило светозвуковое шоу. Пережди грозу в безопасном месте."
        code in 51..67 || code in 80..82 -> "Дождь опять без приглашения. Зонт бери, не геройствуй."
        code in 71..77 || code == 85 || code == 86 -> "Снег пошёл. Дороги могут быть скользкими, так что без гонок."
        temp <= -12 -> "На улице дубак. Одевайся по-человечески, а не на спор."
        temp >= 29 -> "Солнце включило режим духовки. Вода и тень сегодня твои друзья."
        wind >= 45 -> "Ветер разошёлся. Капюшон держи, планы перепроверь."
        code == 0 -> "Небеса сегодня молодцы. Можно выйти без погодной драмы."
        else -> "Погодный скандал пока отменяется. Жить можно."
    }
}
