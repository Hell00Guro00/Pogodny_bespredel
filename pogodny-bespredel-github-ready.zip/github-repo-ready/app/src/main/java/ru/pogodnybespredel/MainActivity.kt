package ru.pogodnybespredel

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch

private val Bg = Color(0xFF090D15)
private val CardBg = Color(0xFF111A28)
private val Acid = Color(0xFFD6FF62)
private val Muted = Color(0xFF92A2B8)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme(colorScheme = darkColorScheme(primary = Acid, background = Bg, surface = Card)) { WeatherScreen() } }
    }
}

@Composable
private fun WeatherScreen() {
    var city by remember { mutableStateOf("Хельсинки") }
    var weather by remember { mutableStateOf<WeatherNow?>(null) }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    val scope = rememberCoroutineScope()
    val pulse by rememberInfiniteTransition(label = "pulse").animateFloat(
        initialValue = 0.96f, targetValue = 1.04f,
        animationSpec = infiniteRepeatable(tween(1800, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "pulseScale"
    )
    fun refresh() {
        scope.launch {
            loading = true; error = null
            runCatching { WeatherRepository.current(60.1699, 24.9384) }
                .onSuccess { weather = it }
                .onFailure { error = "Не удалось достучаться до погодного сервера. Проверь интернет." }
            loading = false
        }
    }
    LaunchedEffect(Unit) { refresh() }

    Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF1B2A40), Bg)))) {
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(18.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("☈", color = Acid, fontSize = 30.sp, fontWeight = FontWeight.Black)
                Spacer(Modifier.width(10.dp))
                Column { Text("ПОГОДНЫЙ", fontSize = 12.sp, fontWeight = FontWeight.Black, letterSpacing = 2.sp); Text("БЕСПРЕДЕЛ", fontSize = 12.sp, fontWeight = FontWeight.Black, letterSpacing = 2.sp) }
                Spacer(Modifier.weight(1f))
                TextButton(onClick = { refresh() }) { Text("↻ ОБНОВИТЬ", color = Acid) }
            }
            Spacer(Modifier.height(26.dp))
            Text("ГДЕ ТЫ ТАМ И ПОГОДА", color = Muted, fontSize = 10.sp, letterSpacing = 2.sp)
            Text(city, fontSize = 28.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(14.dp))
            Card(shape = RoundedCornerShape(28.dp), colors = CardDefaults.cardColors(containerColor = CardBg)) {
                Column(Modifier.padding(22.dp)) {
                    if (loading && weather == null) CircularProgressIndicator(color = Acid)
                    weather?.let { w ->
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text("${w.temperature.toInt()}°", fontSize = 76.sp, fontWeight = FontWeight.Light, letterSpacing = (-5).sp)
                                Text(w.description, fontWeight = FontWeight.Bold)
                                Text("Ощущается как ${w.feelsLike.toInt()}°", color = Muted, fontSize = 12.sp)
                            }
                            Text(w.icon, fontSize = 58.sp, modifier = Modifier.scale(pulse))
                        }
                        Spacer(Modifier.height(22.dp))
                        Text("⚡ ВЕРДИКТ НЕБЕСНОЙ КАНЦЕЛЯРИИ", color = Acid, fontSize = 10.sp, fontWeight = FontWeight.Black, letterSpacing = 1.sp)
                        Spacer(Modifier.height(8.dp))
                        Text(w.comment, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, lineHeight = 22.sp)
                        Spacer(Modifier.height(18.dp))
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Metric("ВЛАЖНОСТЬ", "${w.humidity}%")
                            Metric("ВЕТЕР", "${w.wind.toInt()} км/ч")
                            Metric("ДАВЛЕНИЕ", "${w.pressure.toInt()}")
                        }
                    }
                    if (error != null) Text(error!!, color = Color(0xFFFFB36B), fontSize = 13.sp)
                    if (weather == null && !loading) Button(onClick = { refresh() }) { Text("ПОПРОБОВАТЬ СНОВА") }
                }
            }
            Spacer(Modifier.height(18.dp))
            Text("ПРОГНОЗ ПОКА В РАЗРАБОТКЕ", color = Muted, fontSize = 10.sp, letterSpacing = 1.5.sp)
            Text("Это первый нативный каркас. Следующий шаг: поиск городов, почасовой прогноз, избранное и настройки крепости ругани.", color = Color(0xFFCAD5E3), fontSize = 13.sp, lineHeight = 20.sp)
            Spacer(Modifier.height(26.dp))
            Text("Версия Android-каркаса 0.1.0 · Open-Meteo", color = Muted, fontSize = 10.sp)
        }
    }
}

@Composable
private fun Metric(label: String, value: String) {
    Column {
        Text(label, color = Muted, fontSize = 9.sp, letterSpacing = 1.sp)
        Text(value, color = Color.White, fontSize = 19.sp, fontWeight = FontWeight.Bold)
    }
}
